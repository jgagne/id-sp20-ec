//@line 36 "/builds/slave/rel-m-192-osx-bld/build/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/builds/slave/rel-m-192-osx-bld/build/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
