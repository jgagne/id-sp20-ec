//@line 2 "/builds/slave/rel-m-192-osx-bld/build/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "release");
