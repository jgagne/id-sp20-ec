// Mac specific auto configuration preference defaults
platform.value = "macintosh";
